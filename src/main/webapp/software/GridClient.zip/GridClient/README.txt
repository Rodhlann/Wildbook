To use the Grid Client with your instance of Wildbook, you need to configure the .bat file and/or the .sh file to run in your environment. Java 6+ is a prerequisite to run this client.

Example .bat config:

java -classpath .;jdo-api-3.1-rc1.jar;datanucleus-core-4.0.3.jar;datanucleus-api-jdo-4.0.3.jar -Xms256m -Xmx4096m org.ecocean.grid.WorkApplet3 www.whaleshark.org

Example .sh config (for Linux and Mac):

#! /bin/sh
cd /Users/Jason/sharkGrid
java -classpath .:jdo-api-3.1-rc1.jar:datanucleus-core-4.0.3.jar:datanucleus-api-jdo-4.0.3.jar -Xms256m -Xmx4096m org.ecocean.grid.WorkApplet3 www.whaleshark.org

