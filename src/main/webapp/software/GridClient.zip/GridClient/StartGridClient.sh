#! /bin/sh
# cd <your_path_to_the_client_here>
# java -classpath .:weka-stable-3.6.12.jar:jdo-api-3.1-rc1.jar:datanucleus-core-4.0.3.jar:datanucleus-api-jdo-4.0.3.jar -Xms256m -Xmx4096m org.ecocean.grid.WorkApplet3 www.whaleshark.org
